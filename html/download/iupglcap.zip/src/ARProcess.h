#ifndef __ARPROCESS_H
#define __ARPROCESS_H

#if defined(__cplusplus)
extern "C" {
#endif

void arReset(imImage* image, int *flags, double value1, double value2);
void arProcess(unsigned char* gl_data, imImage *image, int *flags, double value1, double value2);
void arRepaint(int left, int *flags, double value1, double value2);
void arRelease(void);

#if defined(__cplusplus)
}
#endif

#endif
